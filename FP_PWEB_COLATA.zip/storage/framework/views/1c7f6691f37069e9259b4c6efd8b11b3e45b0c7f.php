<?php $__env->startSection('boardcontent'); ?>
	<div class="personalboard">
		<h3>Personal Board</h3>
		
		<div class="card-columns my-container">
		<?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="card text-xs-center" id="board<?php echo e($p->id); ?>">
				<div class="card-block">
					<blockquote class="card-blockquote">
						<p><?php echo e($p->title); ?></p>
					</blockquote>
				</div>
				<div class="card-block">
					<a class="btn red" href='<?php echo e(URL::to('/board/'.$p->id)); ?>'></a>
				</div>
				<a href='<?php echo e(URL::to('/deleteboard/'.$p->id)); ?>'>DELETE</a>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>

	<script type="text/javascript">
		$(document).ready(function() {
			$('#v-pills-home-tab').removeClass('active');
			$('#v-pills-home-tab').removeClass('show');
			$('#v-pills-home-tab').attr("aria-selected", "false");
			$('#v-pills-boards-tab').addClass('active');
			$('#v-pills-boards-tab').addClass('show');
			$('#v-pills-boards-tab').attr("aria-selected", "true");
			$('.homecontent').hide();
		});
	</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>