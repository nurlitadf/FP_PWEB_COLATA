<!DOCTYPE html>
<html>
<head>
	<title>View Profile</title>
</head>
<body>
	Nama : <?php echo e(Auth::user()->name); ?> <br>
	Username : <?php echo e(Auth::user()->username); ?> <br>
	Email : <?php echo e(Auth::user()->email); ?> <br>

	<form action=<?php echo e(route('editprofile')); ?> method="get">
		<?php echo e(csrf_field()); ?>

		<button type="submit">Edit Profile</button>
	</form>
</body> 
</html>