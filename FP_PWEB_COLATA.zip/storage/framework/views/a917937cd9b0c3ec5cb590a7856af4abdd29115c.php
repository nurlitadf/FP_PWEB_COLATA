<?php if(Route::has('login')): ?>
    <div class="top-right links header clear">
    	
    	<div style="float: left">
	    	<a class="logocolata" href="<?php echo e(url('/')); ?>">
	    		<img src="<?php echo e(asset('images/logocolata.png')); ?>" alt>
	    	</a>
    	</div>

    	<?php echo $__env->yieldContent('navcontent'); ?>

    	<div style="float: right;">
    		<?php if(Request::is('/register') OR Request::is('/')): ?>
    			<?php if(auth()->guard()->check()): ?>
            		<a class="navlink" href="<?php echo e(url('/home')); ?>">Home</a>
        		<?php else: ?>
            		<a class="navlink" href="<?php echo e(route('register')); ?>">Register</a>
            		<a class="navlink" href="<?php echo e(route('login')); ?>">Login</a>
        		<?php endif; ?>
        	<?php else: ?>
        		<?php if(auth()->guard()->guest()): ?>
		            <a class="navlink" href="<?php echo e(route('register')); ?>">Register</a>
            		<a class="navlink" href="<?php echo e(route('login')); ?>">Login</a>
		        <?php else: ?>
		            <div class="nav-item dropdown">
		                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
		                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
		                </a>

		                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
		                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
		                        <?php echo e(__('Logout')); ?>

		                    </a>

		                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
		                        <?php echo e(csrf_field()); ?>

		                    </form>
		                </div>
		            </div>
		        <?php endif; ?>
    		<?php endif; ?>
      	</div>
    </div>
<?php endif; ?>

