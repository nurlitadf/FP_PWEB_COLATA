<!DOCTYPE html>
<html>
<head>
	<title>Edit Profile</title>
</head>
<body>
	<form action=<?php echo e(route('updateprofile')); ?> method="post">
		<?php echo e(csrf_field()); ?>

		Nama: <input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>"> <br>
		Username : <input type="text" name="username" value="<?php echo e(Auth::user()->username); ?>"> <br>
		Email : <input type="email" name="email" value="<?php echo e(Auth::user()->email); ?>"> <br>
		Password : <input type="password" name="password"> <br>
		<button type="submit">Submit</button>
		<?php echo e($error); ?><br>
	</form>

	<form action=<?php echo e(route('editpassword')); ?> method="post">
		<?php echo e(csrf_field()); ?>

		Old Password : <input type="password" name="oldpassword"> <br>
		Password : <input type="password" name="newpassword"> <br>
		Confirm Password : <input type="password" name="newpassword2"> <br>
		<button type="submit">Submit</button>
		<?php echo e($log); ?><br>
	</form>
</body>
</html>