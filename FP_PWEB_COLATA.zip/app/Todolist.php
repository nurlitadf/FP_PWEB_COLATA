<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Todolist extends Model
{
    //
    protected $fillable = [
        'title','deadline','board_id', 'keterangan', 'status',
    ];

    public $timestamps = false;
}
